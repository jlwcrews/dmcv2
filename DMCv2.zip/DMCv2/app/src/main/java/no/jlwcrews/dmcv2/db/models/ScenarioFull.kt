package no.jlwcrews.dmcv2.db.models

import java.io.Serializable

class ScenarioFull: Serializable{

}